
import streamlit as st

st.set_page_config(page_title="Nifty 5-min CALL/PUT Signal", layout="wide")

st.title("🔔 Nifty Buy CALL / PUT Signal Bot")
st.markdown("Updates every **1 minute** | Timeframe: **5-Min**")

# Signal Logic Placeholder
signal = "BUY CALL"
reason = "RSI = 28, PCR = 1.3, OI Trend = Bullish"
target1 = "+30 pts"
target2 = "+50 pts"
stoploss = "-20 pts"

st.subheader("📢 Signal")
st.metric("Signal", signal)
st.metric("🎯 Target 1", target1)
st.metric("🎯 Target 2", target2)
st.metric("🛑 Stop Loss", stoploss)
st.markdown(f"**Reason**: {reason}")

st.markdown("---")
st.markdown("Made for Sanjay Joshi | Powered by Streamlit")
